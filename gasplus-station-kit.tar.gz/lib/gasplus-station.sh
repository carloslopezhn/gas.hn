#!/bin/bash
# =============================================================================
# lib/gasplus-station.sh — librería ÚNICA de provisión de una estación Gas+.
# -----------------------------------------------------------------------------
# La usan los DOS caminos de instalación (docs/instalacion-estandar.md):
#   · VHDX Hyper-V  → /opt/gasplus/firstboot.sh (g+ Installer + cloud-init)
#   · Ubuntu nativo → scripts/install-ubuntu.sh  (gas.hn/install-ubuntu.sh)
# Así no hay un segundo camino divergente: la hora, la higiene, la carga de
# imágenes y la cadena de update (botón "Actualizar") salen de ESTAS funciones.
#
# Todas son idempotentes y "escribir si falta": re-correrlas (cada arranque en la
# VHDX, cada re-ejecución del instalador) NUNCA pisa algo que ops corrigió a mano
# (p.ej. un update-gasplus v4 más nuevo vía rollout_v4.sh, o una .registry-cred
# re-sembrada con la credencial de solo lectura — incidente La Flecha 2026-09-26).
#
# Requiere root. Nada de esto comanda hardware (MANTENIMIENTO §17).
# =============================================================================
GP_OPT="${GP_OPT:-/opt/gasplus}"
GP_LIB="${GP_LIB:-$GP_OPT/lib}"
GP_USER="${GP_USER:-gas}"
GP_HOME="${GP_HOME:-/home/$GP_USER}"
GP_REGISTRY="${GP_REGISTRY:-registry.gas.hn}"
GP_IMAGE_TAG="${GP_IMAGE_TAG:-pos-gas:blindado}"   # lo que espera el compose canónico

gp_say(){ echo "gas+ $*"; }

# Valor de una clave del .env de la estación (sin comillas, primera ocurrencia).
gp_env_get(){ { grep -E "^$1=" "$GP_OPT/.env" 2>/dev/null || true; } | head -1 | cut -d= -f2- | tr -d '\r'; }

# ── Hora de Honduras + NTP hn.pool.ntp.org (MANTENIMIENTO §25) ─────────────────
gp_hora(){
  mkdir -p /etc/systemd/timesyncd.conf.d
  if [ ! -s /etc/systemd/timesyncd.conf.d/gasplus.conf ] && [ -r "$GP_OPT/etc/systemd/timesyncd.conf.d/gasplus.conf" ]; then
    cp "$GP_OPT/etc/systemd/timesyncd.conf.d/gasplus.conf" /etc/systemd/timesyncd.conf.d/gasplus.conf
    systemctl restart systemd-timesyncd 2>/dev/null || true
  fi
  timedatectl set-timezone America/Tegucigalpa 2>/dev/null || true
  timedatectl set-ntp true 2>/dev/null || true
}

# ── Higiene de disco (MANTENIMIENTO §7.1 · docs/higiene-disco.md) ──────────────
# journald ≤ 200 MB / 1 mes y logs de docker json-file 10m×3. daemon.json se MEZCLA
# (no pisa otras claves) y NUNCA se reinicia dockerd en caliente: rige desde el próximo
# arranque de docker (en una instalación nueva, desde el primero).
gp_higiene(){
  mkdir -p /etc/systemd/journald.conf.d /etc/docker
  if [ -r "$GP_OPT/etc/systemd/journald.conf.d/gasplus.conf" ] && \
     ! cmp -s "$GP_OPT/etc/systemd/journald.conf.d/gasplus.conf" /etc/systemd/journald.conf.d/gasplus.conf; then
    cp "$GP_OPT/etc/systemd/journald.conf.d/gasplus.conf" /etc/systemd/journald.conf.d/gasplus.conf
    systemctl restart systemd-journald 2>/dev/null || true
  fi
  python3 - <<'PY' 2>&1 || true
import json, os
p = "/etc/docker/daemon.json"; old = open(p).read() if os.path.exists(p) else None
try:
    d = json.loads(old) if (old or "").strip() else {}
except Exception:
    print("gas+ higiene: daemon.json inválido — no se toca"); raise SystemExit(0)
d.setdefault("log-driver", "json-file")
if d["log-driver"] == "json-file":
    o = d.setdefault("log-opts", {}); o.setdefault("max-size", "10m"); o.setdefault("max-file", "3")
new = json.dumps(d, indent=2) + "\n"
if new != old:
    open(p + ".tmp", "w").write(new); os.replace(p + ".tmp", p)
PY
}

# ── Swap: sin swap la presión de memoria es OOM (landmine La Flecha 2026-09-23) ──
gp_swap(){
  [ "$(swapon --noheadings 2>/dev/null | wc -l)" -gt 0 ] && return 0
  local ram_mb; ram_mb=$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo)
  [ "$ram_mb" -ge 16000 ] && return 0
  local free_gb; free_gb=$(df -BG --output=avail / | tail -1 | tr -dc 0-9)
  [ "${free_gb:-0}" -lt 20 ] && return 0
  if [ ! -f /swapfile ]; then
    fallocate -l 2G /swapfile 2>/dev/null || dd if=/dev/zero of=/swapfile bs=1M count=2048 status=none
    chmod 600 /swapfile; mkswap /swapfile >/dev/null
  fi
  swapon /swapfile 2>/dev/null || true
  grep -q '^/swapfile ' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
  sysctl -q vm.swappiness=10 2>/dev/null || true
  echo 'vm.swappiness=10' > /etc/sysctl.d/90-gasplus-swap.conf
  gp_say "swap: 2 GB en /swapfile (swappiness 10)"
}

# ── Imágenes horneadas (VHDX): docker load del tar y borrarlo ──────────────────
gp_cargar_tars(){
  if ! docker image inspect "$GP_IMAGE_TAG" >/dev/null 2>&1 && [ -f "$GP_OPT/pos-gas-blindado.tar.gz" ]; then
    gp_say "cargando imagen $GP_IMAGE_TAG…"
    docker load < "$GP_OPT/pos-gas-blindado.tar.gz" && rm -f "$GP_OPT/pos-gas-blindado.tar.gz"
  fi
  if ! docker image inspect gasplus-agente:latest >/dev/null 2>&1 && [ -f "$GP_OPT/agente-blindado.tar.gz" ]; then
    gp_say "cargando imagen gasplus-agente…"
    docker load < "$GP_OPT/agente-blindado.tar.gz" && rm -f "$GP_OPT/agente-blindado.tar.gz"
  fi
}

# ── Cadena de update (botón "Actualizar" del panel, MANTENIMIENTO §3.1b/§3.3) ──
# panel → agente /update → SSH RESTRINGIDO (command= fijo) → update-gasplus v4
# (manifiesto FIRMADO Ed25519 + pull por digest + anti-rollback). Se activa si el
# .env trae los secretos que devuelve /api/provision-station (UPDATE_KEY + REGISTRY_*).
# Credencial del registry: SIEMPRE la de SOLO LECTURA (§3.3 P2) — la entrega el panel.
gp_cadena_update(){
  local UPDATE_KEY REG_USER REG_PASS GH="$GP_HOME" AK
  UPDATE_KEY="$(gp_env_get UPDATE_KEY)"; REG_USER="$(gp_env_get REGISTRY_USER)"; REG_PASS="$(gp_env_get REGISTRY_PASS)"
  if [ -z "$UPDATE_KEY" ] || [ -z "$REG_USER" ] || [ -z "$REG_PASS" ] || ! id "$GP_USER" &>/dev/null; then
    gp_say "cadena de update: omitida (faltan UPDATE_KEY/REGISTRY_* en el .env o el usuario $GP_USER)"; return 0
  fi
  chown "root:$GP_USER" "$GP_OPT/.env" 2>/dev/null; chmod 640 "$GP_OPT/.env" 2>/dev/null   # gas lee el .env → compose sin sudo
  install -d -o "$GP_USER" -g "$GP_USER" -m 700 "$GH/.agent-update" "$GH/.ssh"
  [ -f "$GH/.agent-update/id_ed25519" ] || sudo -u "$GP_USER" ssh-keygen -t ed25519 -N '' -q -C agent-update -f "$GH/.agent-update/id_ed25519"
  if [ ! -s "$GH/.update-key" ]; then
    printf '%s' "$UPDATE_KEY" > "$GH/.update-key"; chown "$GP_USER:$GP_USER" "$GH/.update-key"; chmod 600 "$GH/.update-key"
  fi
  if [ ! -s "$GH/.registry-cred" ]; then
    { echo "REGISTRY_USER=$REG_USER"; echo "REGISTRY_PASS=$REG_PASS"; echo "REGISTRY_HOST=$GP_REGISTRY"; } > "$GH/.registry-cred"
    chown "$GP_USER:$GP_USER" "$GH/.registry-cred"; chmod 600 "$GH/.registry-cred"
  fi
  # Llave PÚBLICA de firma de imágenes (= gasplus/scripts/keys/gasplus-image-signing.pub).
  if [ ! -s "$GH/.image-signing.pub" ]; then
    install -o "$GP_USER" -g "$GP_USER" -m 644 "$GP_LIB/image-signing.pub" "$GH/.image-signing.pub"
  fi
  # Base = update-gasplus v4 (= gasplus/scripts/update-gasplus-v4.sh). Solo si falta o si
  # el que hay NO verifica firma (v3 viejo): un v4 más nuevo puesto por ops se respeta.
  if [ ! -s "$GH/update-gasplus-base.sh" ] || ! grep -q 'pkeyutl -verify' "$GH/update-gasplus-base.sh"; then
    install -o "$GP_USER" -g "$GP_USER" -m 700 "$GP_LIB/update-gasplus-v4.sh" "$GH/update-gasplus-base.sh"
  fi
  # Wrapper del layout /opt/gasplus (landmine §3.3: SIN GASPLUS_IMAGE_TAG el pull no recrea).
  cat > "$GH/update-gasplus.sh.tmp" <<WRAP
#!/bin/bash
set -euo pipefail
export GASPLUS_COMPOSE_DIR=$GP_OPT GASPLUS_SUDO="" GASPLUS_IMAGE_TAG="$GP_IMAGE_TAG" GASPLUS_SMOKE_PORT="5002"
exec $GH/update-gasplus-base.sh "\$@"
WRAP
  if cmp -s "$GH/update-gasplus.sh.tmp" "$GH/update-gasplus.sh"; then rm -f "$GH/update-gasplus.sh.tmp"
  else mv -f "$GH/update-gasplus.sh.tmp" "$GH/update-gasplus.sh"; fi
  chown "$GP_USER:$GP_USER" "$GH/update-gasplus.sh"; chmod 700 "$GH/update-gasplus.sh"
  # SSH restringido: la llave del agente SOLO puede disparar el update.
  AK="$GH/.ssh/authorized_keys"; touch "$AK"; chown "$GP_USER:$GP_USER" "$AK"; chmod 600 "$AK"
  if ! grep -qF "$(awk '{print $2}' "$GH/.agent-update/id_ed25519.pub")" "$AK"; then
    echo "command=\"$GH/update-gasplus.sh\",no-port-forwarding,no-agent-forwarding,no-X11-forwarding,no-pty $(cat "$GH/.agent-update/id_ed25519.pub") agent-update-firstboot" >> "$AK"
  fi
  if [ ! -s "$GP_OPT/docker-compose.override.yml" ]; then
    cat > "$GP_OPT/docker-compose.override.yml" <<OVR
services:
  agente:
    environment:
      AGENT_UPDATE_CMD: "ssh -p 22 -i /agent-update/id_ed25519 -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o BatchMode=yes $GP_USER@host.docker.internal update"
    extra_hosts:
      - "host.docker.internal:host-gateway"
    volumes:
      - $GH/.agent-update:/agent-update:ro
OVR
  fi
  systemctl enable --now ssh >/dev/null 2>&1 || systemctl enable --now sshd >/dev/null 2>&1 || true
  gp_say "cadena de update lista (update-gasplus v4 firmado + SSH restringido + override del agente)"
}

# ── Levantar el stack (sin build, siempre -p pos_gas) ──────────────────────────
# Reintenta: en el primer arranque la DB puede tardar en quedar healthy (init + carga de
# imágenes en una VM lenta) y un `up` fallido dejaba pos-gas SIN crear hasta el próximo boot.
gp_stack_up(){
  local i rc=1
  for i in 1 2 3 4 5; do
    ( cd "$GP_OPT" && docker compose -p pos_gas up -d --no-build 2>&1 | tail -20; exit "${PIPESTATUS[0]}" ) && { rc=0; break; }
    gp_say "compose up falló (intento $i/5) — reintento en 30 s"; sleep 30
  done
  return $rc
}
