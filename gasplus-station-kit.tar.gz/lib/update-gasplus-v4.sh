#!/bin/bash
# update-gasplus.sh v4 (2026-09-19) — Gas+ estación: actualiza por REGISTRY con
# FIRMA VERIFICADA. Igual que v3 (pull POR DIGEST = integridad de contenido) pero
# la estación ya NO se fía de lo que diga el panel: lee un MANIFIESTO firmado
# (Ed25519) con la llave privada que vive SOLO en el T40, y lo verifica con la
# llave pública sembrada en la estación. Un panel comprometido (o un registry
# comprometido) NO puede empujar una imagen que el T40 no firmó.
#   integridad  = pull por digest (sha256 de cada capa, Docker lo verifica)
#   autenticidad= firma Ed25519 del manifiesto (version/repo/digest/issued_at)
#   anti-replay = issued_at monotónico (estado en $STATE) + antigüedad máxima
# Lo dispara el agente (panel -> /update) vía SSH restringido (command=).
# Overrides por estación: GASPLUS_COMPOSE_DIR, GASPLUS_SUDO, GASPLUS_IMAGE_TAG,
#   GASPLUS_SMOKE_PORT, PANEL_URL, REGISTRY_HOST, GASPLUS_SIGNING_PUB, GASPLUS_MAX_AGE_DAYS,
#   GASPLUS_HOME, GASPLUS_PROJECT, GASPLUS_SERVICE, GASPLUS_CONTAINER.
#
# Los cuatro últimos (2026-09-20) existen porque la estación DEMO corre en el MISMO
# daemon Docker que la producción de Siguatepeque: con `-p pos_gas` y `pos-gas`
# fijos, un update del demo habría recreado el contenedor de PRODUCCIÓN. Los
# defaults son EXACTAMENTE los valores históricos → las 6 estaciones de campo no
# cambian de comportamiento.
set -euo pipefail
D="${GASPLUS_SUDO:-}"
GHOME="${GASPLUS_HOME:-/home/gas}"           # dueño de .update-key/.registry-cred
PROJECT="${GASPLUS_PROJECT:-pos_gas}"        # docker compose -p
SERVICE="${GASPLUS_SERVICE:-pos-gas}"        # servicio del compose
CTR="${GASPLUS_CONTAINER:-pos-gas}"          # container_name (smoke)
KEY="$(cat "$GHOME/.update-key")"
PANEL="${PANEL_URL:-https://panel.gas.hn}"
PUB="${GASPLUS_SIGNING_PUB:-$GHOME/.image-signing.pub}"
STATE="${GASPLUS_UPDATE_STATE:-$GHOME/.gasplus-update-state}"
MAX_AGE_DAYS="${GASPLUS_MAX_AGE_DAYS:-120}"
W="$(mktemp -d)"; trap 'rm -rf "$W"' EXIT

# >>> limpieza-imagenes (MANTENIMIENTO §3.3 — incidente Peña Blanca 2026-09-30) >>>
# Cada update por digest deja la imagen anterior SIN tag pero con referencia
# repo@digest: NO es "dangling", así que `docker image prune -f` no la borra y el
# disco se llena (PB 19 GB: 146 imágenes de ~480 MB → la DB falló escribiendo).
# Conserva: la imagen en uso (tag del compose), la anterior (<repo>:rollback-prev),
# toda imagen usada por un contenedor (corriendo o parado) y los tags nombrados a
# mano (rollback-prev, prev-<ver>, pre-<sha>…) cuya imagen tiene < 7 días. Del resto quita SOLO las
# referencias de los repos de Gas+ (pos-gas por digest, el repo del tag y, en
# estaciones, mcp): una imagen que tenga otro tag fuera de esos repos sobrevive.
# Nunca toca volúmenes ni contenedores. Best-effort: jamás hace fallar el update.
#   gp_limpiar_imagenes <tag-en-uso> [id-anterior] [repos-extra]   (GP_DRY=1 = simulacro)
gp_limpiar_imagenes() {
  set +e
  local TAG_="$1" PREV_="${2:-}" EXTRA_="${3:-}"
  local TREPO="" RB="" DRY="${GP_DRY:-}" NOW="" A0="" A1="" CUR="" RBID="" KEEP="" n=0 repo="" tag="" dig="" id="" cr="" ref=""
  local DK="${D:-} docker"
  case "${TAG_##*/}" in *:*) ;; *) TAG_="$TAG_:latest";; esac   # "repo" → "repo:latest"
  TREPO="${TAG_%:*}"; RB="$TREPO:rollback-prev"; NOW=$(date +%s)
  A0=$(df -B1 --output=avail / 2>/dev/null | tail -1 | tr -dc 0-9)
  CUR=$($DK image inspect -f '{{.Id}}' "$TAG_" 2>/dev/null)
  [ -n "$CUR" ] || { echo "limpieza: omitida (no existe $TAG_)"; return 0; }
  local REPOS=" registry.gas.hn/gasplus/pos-gas ${REGISTRY_HOST:-registry.gas.hn}/gasplus/pos-gas $TREPO $EXTRA_ "
  # La anterior → rollback-prev (si el update trajo una imagen distinta).
  if [ -n "$PREV_" ] && [ "$PREV_" != "$CUR" ]; then
    [ -n "$DRY" ] && echo "  [dry] tag $PREV_ → $RB" || $DK tag "$PREV_" "$RB"
  fi
  # Sin anterior conocida: la más nueva de pos-gas distinta de la actual (docker images = más nueva primero).
  if ! $DK image inspect "$RB" >/dev/null 2>&1; then
    local cand
    cand=$($DK images --no-trunc --format '{{.ID}} {{.Repository}}' | awk -v c="$CUR" -v r="$TREPO" \
      '$1!=c && ($2 ~ /\/gasplus\/pos-gas$/ || $2==r) {print $1; exit}')
    [ -n "$cand" ] && { [ -n "$DRY" ] && echo "  [dry] tag $cand → $RB" || $DK tag "$cand" "$RB"; }
    [ -n "$DRY" ] && RBID="$cand"
  fi
  [ -n "${RBID:-}" ] || RBID=$($DK image inspect -f '{{.Id}}' "$RB" 2>/dev/null)
  KEEP=" $CUR ${RBID:-} "
  for c in $($DK ps -aq); do KEEP="$KEEP $($DK inspect -f '{{.Image}}' "$c" 2>/dev/null) "; done
  # 1ª pasada: tags NOMBRADOS a mano (rollback-*, prev-*, pre-<sha>, …; no "latest") cuya
  # imagen tiene < 7 días se conservan. Los de más de 7 días se van.
  while IFS='|' read -r repo tag dig id; do
    case "$REPOS" in *" $repo "*) ;; *) continue;; esac
    case "$tag" in latest|"<none>") continue;; esac
    cr=$(date -d "$($DK image inspect -f '{{.Created}}' "$id" 2>/dev/null)" +%s 2>/dev/null || echo 0)
    [ $((NOW - cr)) -lt 604800 ] && KEEP="$KEEP $id "
  done < <($DK images --no-trunc --digests --format '{{.Repository}}|{{.Tag}}|{{.Digest}}|{{.ID}}')
  # 2ª pasada: quitar las referencias del resto.
  while IFS='|' read -r repo tag dig id; do
    case "$REPOS" in *" $repo "*) ;; *) continue;; esac
    case "$KEEP" in *" $id "*) continue;; esac
    for ref in $([ "$tag" != "<none>" ] && echo "$repo:$tag") $([ "$dig" != "<none>" ] && echo "$repo@$dig"); do
      if [ -n "$DRY" ]; then echo "  [dry] rmi $ref"; n=$((n+1))
      else $DK rmi "$ref" >/dev/null 2>&1 && n=$((n+1)); fi
    done
  done < <($DK images --no-trunc --digests --format '{{.Repository}}|{{.Tag}}|{{.Digest}}|{{.ID}}')
  if [ -z "$DRY" ]; then
    $DK image prune -f >/dev/null 2>&1
    $DK builder prune -f >/dev/null 2>&1
  fi
  A1=$(df -B1 --output=avail / 2>/dev/null | tail -1 | tr -dc 0-9)
  echo "limpieza: $n referencias quitadas · liberado $(( (${A1:-0} - ${A0:-0}) / 1048576 )) MB · conservadas: actual ${CUR:7:12}, rollback-prev ${RBID:7:12}"
  return 0
}
# <<< limpieza-imagenes <<<

# >>> higiene-host (MANTENIMIENTO §7 · docs/higiene-disco.md — "evitemos guardar basura", CEO 2026-09-30) >>>
# Idempotente y best-effort (jamás hace fallar el update). Requiere root: usa sudo -n si
# está; si no, lo informa y sigue. NUNCA reinicia dockerd ni contenedores.
#  1) journald: tope 200 MB / 1 mes (drop-in propio; el default es 10 % del disco ≤ 4 GB).
#  2) /etc/docker/daemon.json: log json-file 10m×3 (merge, no pisa otras claves). Rige para
#     contenedores CREADOS después del próximo arranque de dockerd (reinicio de la VM);
#     se valida con `dockerd --validate` y se revierte si no valida.
#  3) apt-get clean.  4) /tmp: archivos de `gas` con > 10 días (scripts de ops sueltos).
gp_higiene_host() {
  set +e
  local S=""
  if [ "$(id -u)" != 0 ]; then sudo -n true 2>/dev/null && S="sudo -n" || { echo "higiene: omitida (sin sudo -n)"; return 0; }; fi
  local J=/etc/systemd/journald.conf.d/gasplus.conf
  local JC='[Journal]\nSystemMaxUse=200M\nSystemKeepFree=1G\nMaxRetentionSec=1month\n'
  if [ "$(cat "$J" 2>/dev/null)" != "$(printf "$JC")" ]; then
    $S mkdir -p /etc/systemd/journald.conf.d && printf "$JC" | $S tee "$J" >/dev/null \
      && $S systemctl restart systemd-journald && $S journalctl --vacuum-size=200M >/dev/null 2>&1
  fi
  $S python3 - <<'PY' 2>&1
import json, os, shutil, subprocess
p = "/etc/docker/daemon.json"; old = open(p).read() if os.path.exists(p) else None
try:
    d = json.loads(old) if (old or "").strip() else {}
except Exception:
    print("higiene: daemon.json inválido — no se toca"); raise SystemExit(0)
d.setdefault("log-driver", "json-file")
if d["log-driver"] == "json-file":
    o = d.setdefault("log-opts", {}); o.setdefault("max-size", "10m"); o.setdefault("max-file", "3")
new = json.dumps(d, indent=2) + "\n"
if new != old:
    open(p + ".tmp", "w").write(new); os.replace(p + ".tmp", p)
    r = subprocess.run(["dockerd", "--validate", "--config-file", p], capture_output=True, text=True)
    if r.returncode != 0:
        if old is None: os.remove(p)
        else: open(p, "w").write(old)
        print("higiene: daemon.json no validó — revertido:", (r.stderr or r.stdout).strip()[:200])
PY
  $S apt-get clean >/dev/null 2>&1
  $S find /tmp -mindepth 1 -maxdepth 1 -user gas -mtime +10 -exec rm -rf {} + 2>/dev/null
  echo "higiene: journal $($S journalctl --disk-usage 2>/dev/null | grep -o '[0-9.]*[KMG]' | head -1) · docker log-opts $(grep -o '"max-size": "[^"]*"' /etc/docker/daemon.json 2>/dev/null)"
  return 0
}
# <<< higiene-host <<<

[ -r "$PUB" ] || { echo "!! falta la llave pública de firma ($PUB) — la estación no puede verificar imágenes. Abortado."; exit 2; }

echo "== manifiesto firmado del panel =="
curl -fsS -H "X-Update-Key: $KEY" --max-time 30 "$PANEL/gasplus-image.manifest" -o "$W/manifest"
curl -fsS -H "X-Update-Key: $KEY" --max-time 30 "$PANEL/gasplus-image.sig" | tr -d ' \n\r' | base64 -d > "$W/sig" 2>/dev/null \
  || { echo "!! firma ausente o ilegible ($PANEL/gasplus-image.sig). Abortado."; exit 3; }
[ -s "$W/manifest" ] && [ -s "$W/sig" ] || { echo "!! manifiesto/firma vacíos. Abortado."; exit 3; }
if ! openssl pkeyutl -verify -pubin -inkey "$PUB" -rawin -in "$W/manifest" -sigfile "$W/sig" >/dev/null 2>&1; then
  echo "!! FIRMA INVÁLIDA: el manifiesto no fue firmado por la llave del T40. NO se actualiza."; cat "$W/manifest"; exit 4
fi
echo "  firma OK (Ed25519)"

# Solo se lee lo que está DENTRO del manifiesto firmado (nada de endpoints sueltos).
mf(){ grep -m1 "^$1=" "$W/manifest" | cut -d= -f2- | tr -d '\r'; }
VER="$(mf version)"; REPO="$(mf repo)"; DIGEST="$(mf digest)"; ISSUED="$(mf issued_at)"
case "$DIGEST" in sha256:[0-9a-f]*) ;; *) echo "!! digest inválido en el manifiesto: '$DIGEST'"; exit 5;; esac
case "$REPO" in registry.gas.hn/gasplus/pos-gas|"${REGISTRY_HOST:-registry.gas.hn}"/gasplus/pos-gas) ;; *) echo "!! repo inesperado en el manifiesto: '$REPO'"; exit 5;; esac
case "$ISSUED" in ''|*[!0-9]*) echo "!! issued_at inválido: '$ISSUED'"; exit 5;; esac
NOW="$(date +%s)"
if [ "$ISSUED" -lt $((NOW - MAX_AGE_DAYS*86400)) ]; then
  echo "!! manifiesto demasiado viejo ($(date -d @"$ISSUED" +%F), > $MAX_AGE_DAYS días): posible replay. Publicá una imagen nueva desde el T40."; exit 6
fi
LAST="$(cat "$STATE" 2>/dev/null | tr -dc 0-9 || true)"; LAST="${LAST:-0}"
if [ "$ISSUED" -lt "$LAST" ]; then
  echo "!! ROLLBACK rechazado: el manifiesto ($ISSUED) es anterior al último aplicado ($LAST)."; exit 7
fi
REF="${REPO}@${DIGEST}"
echo "  version=$VER  issued=$(date -d @"$ISSUED" '+%F %T')  digest=${DIGEST:0:19}…"

echo "== docker login registry =="
# shellcheck disable=SC1091
source "$GHOME/.registry-cred"
echo "$REGISTRY_PASS" | $D docker login "${REGISTRY_HOST:-registry.gas.hn}" -u "$REGISTRY_USER" --password-stdin >/dev/null

TAG="${GASPLUS_IMAGE_TAG:-pos_gas-pos-gas:latest}"
# Imagen que corre HOY (antes del pull): queda como <repo>:rollback-prev tras el update.
OLD_ID="$($D docker image inspect -f '{{.Id}}' "$TAG" 2>/dev/null || true)"

echo "== pull por digest ($VER) — solo capas nuevas =="
$D docker pull "$REF"
# Retag a lo que espera el compose de la estación: pos_gas-pos-gas:latest
# (layout rsync/build) o pos-gas:blindado (layout VHDX /opt/gasplus).
$D docker tag "$REF" "$TAG"

echo "== up (sin build) =="
cd "${GASPLUS_COMPOSE_DIR:-$GHOME/gasplus/backend}"
$D docker compose -p "$PROJECT" up -d --no-build "$SERVICE"
sleep 8
printf '%s' "$ISSUED" > "$STATE" 2>/dev/null || true   # anti-rollback: sólo tras aplicar

echo "== smoke =="
echo "VERSION: $($D docker exec "$CTR" cat /app/VERSION 2>/dev/null || echo '?')"
curl -s -o /dev/null -w "pista: %{http_code}\n" --max-time 12 "http://127.0.0.1:${GASPLUS_SMOKE_PORT:-80}/pista/" || true
{ $D docker logs "$CTR" --since 2m 2>&1 | grep -ciE "traceback" || true; } | xargs echo tracebacks:
# Hora (MANTENIMIENTO §25): sólo AVISA, nunca falla el update.
_sync="$(timedatectl show -p NTPSynchronized --value 2>/dev/null || echo '?')"
_ctz="$($D docker exec "$CTR" date +%z 2>/dev/null || echo '?')"
echo "hora: host NTP sincronizado=$_sync · contenedor UTC$_ctz"
{ [ "$_sync" = yes ] && [ "$_ctz" = "-0600" ]; } || echo "!! AVISO hora: la estación está FUERA del estándar (NTP activo + America/Tegucigalpa)"

# Limpieza de imágenes viejas: SOLO si el contenedor ya corre la imagen nueva.
echo "== limpieza de imágenes viejas =="
if [ "$($D docker inspect -f '{{.Image}}' "$CTR" 2>/dev/null)" = "$($D docker image inspect -f '{{.Id}}' "$TAG" 2>/dev/null)" ]; then
  _extra=""; [ "$PROJECT" = pos_gas ] && _extra="registry.gas.hn/gasplus/mcp pos_gas-pos-gas pos-gas"
  ( gp_limpiar_imagenes "$TAG" "$OLD_ID" "$_extra" ) 2>&1 || true
else
  echo "limpieza: omitida ($CTR no corre la imagen nueva — se conserva todo para diagnóstico)"
fi
# Higiene del host (docs/higiene-disco.md): sólo estaciones de campo (el demo comparte
# daemon con la producción de Sigua en el T40 → jamás tocar /etc del T40 desde acá).
if [ "$PROJECT" = pos_gas ]; then
  echo "== higiene de disco =="
  ( gp_higiene_host ) 2>&1 || true
fi
echo "disco: $(df --output=pcent / 2>/dev/null | tail -1 | tr -dc 0-9)%"
echo "== OK v4(registry/digest/firma) =="
