#!/bin/bash
# Arranque de la estación Gas+ (servicio gasplus-firstboot, en CADA arranque).
# Kit único (gasplus/station): lo usan la VHDX de Hyper-V y el instalador de Ubuntu.
# Idempotente. NO compila en el cliente: el fuente .py nunca toca el disco.
#   1) hora de Honduras + NTP (§25) y higiene (§7.1)
#   2) espera el .env (lo inyecta cloud-init en la VHDX; el instalador de Ubuntu lo
#      escribe antes de habilitar este servicio)
#   3) carga las imágenes horneadas si vienen en tar (VHDX)
#   4) cadena de update del botón "Actualizar" (si el .env trae los secretos)
#   5) docker compose -p pos_gas up -d (sin build)
set -uo pipefail
. /opt/gasplus/lib/gasplus-station.sh || { echo "gas+ firstboot: falta /opt/gasplus/lib/gasplus-station.sh"; exit 0; }
cd "$GP_OPT" || exit 0
gp_hora
gp_higiene
for i in $(seq 1 120); do [ -f .env ] && break; sleep 5; done
[ -f .env ] || { echo "gas+ firstboot: sin .env, no se levanta el stack"; exit 0; }
for u in "$GP_USER" ubuntu; do id "$u" &>/dev/null && usermod -aG docker "$u" 2>/dev/null || true; done
gp_cargar_tars
gp_cadena_update
gp_stack_up
