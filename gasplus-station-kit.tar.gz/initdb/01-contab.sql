-- Crea la base 'contab' y su usuario para el módulo contable/bombas (SQLAlchemy, DB_URL).
-- Corre una sola vez, en el primer init del contenedor MariaDB (docker-entrypoint-initdb.d).
CREATE DATABASE IF NOT EXISTS contab CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'contab'@'%' IDENTIFIED BY 'contab_pass';
GRANT ALL PRIVILEGES ON contab.* TO 'contab'@'%';
-- `gasplus_operacion`: base operacional (bombas_*: reporte-ventas, estadigrafo2,
-- cuadres, boletas/aceites/vales que captura el operador). El engine de la app
-- (db.py::_inv_url) deriva de DB_URL cambiando el nombre de base y conecta como
-- 'contab'. Sin este grant, reporte-ventas/estadigrafo2 tiran 1044 'Access denied'
-- en instalaciones nuevas (ensure_inv_db necesita root pw que el compose no daba).
CREATE DATABASE IF NOT EXISTS gasplus_operacion CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
GRANT ALL PRIVILEGES ON gasplus_operacion.* TO 'contab'@'%';
FLUSH PRIVILEGES;
