@echo off
REM Pre-confia el certificado de firma Gas+ (opcional). Correr como ADMIN.
REM Tras esto, Provision-GasPlus.exe corre SIN aviso de editor desconocido,
REM incluso en el primer arranque de la maquina.
net session >nul 2>&1
if %errorlevel% NEQ 0 (
  echo Ejecutando como administrador...
  powershell -Command "Start-Process '%~f0' -Verb RunAs"
  exit /b
)
set CER=%~dp0gasplus-codesign.cer
certutil -addstore -f Root "%CER%"
certutil -addstore -f TrustedPublisher "%CER%"
echo.
echo Certificado Gas+ confiado. Ya puede ejecutar Provision-GasPlus.exe sin avisos.
pause
