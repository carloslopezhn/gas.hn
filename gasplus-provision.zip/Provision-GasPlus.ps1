<#
================================================================================
 Provision-GasPlus.ps1  -  Herramienta de habilitacion remota para Gas+
 Grupo UTP - Desarrollo de Software
--------------------------------------------------------------------------------
 Deja una maquina Windows lista para administrarla remotamente (SSH / WinRM /
 RDP) e instalar Gas+ (Hyper-V + VM Ubuntu), igual que en Pena Blanca / PetroColon.

 MODOS:
   .\Provision-GasPlus.ps1                 -> ESTADO (solo lectura, no cambia nada)
   .\Provision-GasPlus.ps1 -Aplicar        -> APLICA los fixes (requiere admin)

 PARAMETROS (para -Aplicar):
   -ZtNetwork  <id>    Red ZeroTier a unir (16 hex). Ej: a581878f7debf3f2
   -SshPubKey  <str>   Llave publica SSH a autorizar (ssh-ed25519 AAAA... o ssh-rsa)
   -AllowCidr  <cidr>  Restringe el firewall remoto a este rango. Ej: 10.14.0.0/16
                       (recomendado el rango ZeroTier; vacio = abre en cualquier red)
   -SkipHyperV         No habilita Hyper-V (util si la maquina no lo necesita)
   -SkipZeroTier       No instala/une ZeroTier
   -NoReboot           No reinicia aunque Hyper-V lo requiera (queda pendiente)

 SEGURIDAD: SSH por llave (no password), RDP con NLA, y si pasas -AllowCidr las
 reglas de firewall se limitan a ese rango. La herramienta NO abre nada a Internet
 por si sola; el acceso externo depende de tu red (ZeroTier / NAT / VPN).
================================================================================
#>
[CmdletBinding()]
param(
  [switch]$Aplicar,
  [string]$ZtNetwork = "",
  [string]$SshPubKey = "",
  [string]$AllowCidr = "",
  [switch]$SkipHyperV,
  [switch]$SkipZeroTier,
  [switch]$NoReboot
)

$ErrorActionPreference = "Continue"
$script:Reboot = $false
$Version = "1.3"
$here = if ($PSScriptRoot) { $PSScriptRoot } elseif ($PSCommandPath) { Split-Path -Parent $PSCommandPath } else { (Get-Location).Path }
$Log = Join-Path $here ("GasPlus-Provision_{0}.log" -f (Get-Date -Format "yyyyMMdd_HHmmss"))

# ---- helpers de salida --------------------------------------------------------
function W([string]$m,[string]$c="Gray"){ Write-Host $m -ForegroundColor $c; Add-Content -Path $Log -Value $m -ErrorAction SilentlyContinue }
function Head([string]$t){ W ""; W ("== " + $t + " ") "Cyan" }
function OK([string]$m){ W ("  [OK]   " + $m) "Green" }
function BAD([string]$m){ W ("  [X]    " + $m) "Red" }
function WARNX([string]$m){ W ("  [!]    " + $m) "Yellow" }
function INFO([string]$m){ W ("  ->     " + $m) "Gray" }

# ---- auto-elevacion a admin ---------------------------------------------------
function Test-Admin { ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) }
if (-not (Test-Admin)) {
  Write-Host "Solicitando permisos de administrador (UAC)..." -ForegroundColor Yellow
  $argl = @("-NoProfile","-ExecutionPolicy","Bypass","-File","`"$PSCommandPath`"")
  if ($Aplicar)      { $argl += "-Aplicar" }
  if ($ZtNetwork)    { $argl += @("-ZtNetwork",$ZtNetwork) }
  if ($SshPubKey)    { $argl += @("-SshPubKey","`"$SshPubKey`"") }
  if ($AllowCidr)    { $argl += @("-AllowCidr",$AllowCidr) }
  if ($SkipHyperV)   { $argl += "-SkipHyperV" }
  if ($SkipZeroTier) { $argl += "-SkipZeroTier" }
  if ($NoReboot)     { $argl += "-NoReboot" }
  Start-Process powershell.exe -Verb RunAs -ArgumentList $argl
  exit
}

W ("Provision-GasPlus v{0}  -  {1}" -f $Version, (Get-Date)) "White"
W ("Log: {0}" -f $Log) "DarkGray"

# ---- reglas de firewall (respetan -AllowCidr) --------------------------------
function Set-FwGroup([string]$group){
  try { Enable-NetFirewallRule -DisplayGroup $group -ErrorAction Stop; return $true } catch { return $false }
}
function New-FwPort([string]$name,[int[]]$ports,[string]$proto="TCP"){
  try {
    Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
    $p = @{ DisplayName=$name; Direction="Inbound"; Action="Allow"; Protocol=$proto; LocalPort=$ports; Profile="Any" }
    if ($AllowCidr) { $p["RemoteAddress"] = $AllowCidr }
    New-NetFirewallRule @p | Out-Null
    return $true
  } catch { return $false }
}
# Habilita un grupo de firewall por su nombre NEUTRAL (@FirewallAPI.dll,-NNN),
# que funciona en Windows en cualquier idioma (los DisplayGroup en ingles fallan
# en un Windows en espanol). Devuelve $true si encendio al menos una regla.
function Enable-FwGroupNeutral([string]$neutral){
  try { Enable-NetFirewallRule -Group $neutral -ErrorAction Stop; return $true } catch { return $false }
}
# Verdadero si hay una regla ENTRANTE/PERMITIR/HABILITADA para ese puerto local,
# sin importar el idioma ni el nombre del grupo.
function FwPortOpen([int]$port){
  try {
    $pf = Get-NetFirewallPortFilter -ErrorAction SilentlyContinue | Where-Object { "$($_.LocalPort)" -split "," -contains "$port" }
    foreach($f in $pf){
      $ru = $f | Get-NetFirewallRule -ErrorAction SilentlyContinue
      foreach($r in $ru){ if ($r.Enabled -eq "True" -and $r.Direction -eq "Inbound" -and $r.Action -eq "Allow") { return $true } }
    }
  } catch {}
  return $false
}

# ============================================================================ #
#  DIAGNOSTICO
# ============================================================================ #
function Get-Estado {
  Head "Sistema"
  $os = Get-CimInstance Win32_OperatingSystem
  $cs = Get-CimInstance Win32_ComputerSystem
  INFO ("Equipo   : {0}" -f $env:COMPUTERNAME)
  INFO ("Windows  : {0} ({1})" -f $os.Caption, $os.Version)
  INFO ("RAM      : {0:N1} GB" -f ($cs.TotalPhysicalMemory/1GB))
  $edicion = (Get-CimInstance Win32_OperatingSystem).OperatingSystemSKU
  # IPs
  $ips = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike "169.*" -and $_.IPAddress -ne "127.0.0.1" }
  foreach($i in $ips){ INFO ("IP       : {0,-16} ({1})" -f $i.IPAddress, $i.InterfaceAlias) }

  Head "Virtualizacion / Hyper-V"
  try {
    $ci = Get-ComputerInfo -Property "HyperV*" -ErrorAction SilentlyContinue
    if ($ci.HyperVRequirementVirtualizationFirmwareEnabled -eq $true -or $ci.HyperVisorPresent -eq $true) { OK "Virtualizacion habilitada en firmware/BIOS" } else { WARNX "Virtualizacion NO detectada en BIOS (revisar VT-x/AMD-V)" }
  } catch { WARNX "No se pudo leer estado de virtualizacion" }
  $hv = (Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All -ErrorAction SilentlyContinue)
  if ($hv -and $hv.State -eq "Enabled") { OK "Hyper-V habilitado" } else { BAD "Hyper-V NO habilitado" }

  Head "Acceso remoto"
  # WinRM
  $winrm = Get-Service WinRM -ErrorAction SilentlyContinue
  if ($winrm -and $winrm.Status -eq "Running") { OK ("WinRM corriendo ({0})" -f $winrm.StartType) } else { BAD "WinRM detenido/deshabilitado" }
  # RDP
  $rdp = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server" -Name fDenyTSConnections -ErrorAction SilentlyContinue).fDenyTSConnections
  if ($rdp -eq 0) { OK "RDP habilitado" } else { BAD "RDP deshabilitado" }
  # OpenSSH
  $sshd = Get-Service sshd -ErrorAction SilentlyContinue
  if ($sshd -and $sshd.Status -eq "Running") { OK ("OpenSSH Server corriendo ({0})" -f $sshd.StartType) }
  elseif ($sshd) { WARNX "OpenSSH Server instalado pero detenido" }
  else { BAD "OpenSSH Server NO instalado" }
  # SMB
  $smb = Get-SmbServerConfiguration -ErrorAction SilentlyContinue
  if ($smb) { OK "Servicio SMB presente" } else { WARNX "No se pudo leer SMB" }

  Head "Firewall (puertos entrantes)"
  foreach($pp in @(@("WinRM",5985),@("RDP",3389),@("SMB",445),@("OpenSSH",22))){
    if (FwPortOpen $pp[1]) { OK ("Puerto abierto: {0} ({1})" -f $pp[0], $pp[1]) } else { BAD ("Puerto cerrado: {0} ({1})" -f $pp[0], $pp[1]) }
  }

  Head "Registro (claves clave)"
  $latfp = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name LocalAccountTokenFilterPolicy -ErrorAction SilentlyContinue).LocalAccountTokenFilterPolicy
  if ($latfp -eq 1) { OK "LocalAccountTokenFilterPolicy = 1 (admin remoto por cuenta local)" } else { BAD "LocalAccountTokenFilterPolicy != 1" }

  Head "Firma de codigo Gas+"
  $trusted = Get-ChildItem Cert:\LocalMachine\TrustedPublisher -ErrorAction SilentlyContinue | Where-Object { $_.Subject -like "*Grupo UTP - Gas+*" }
  if ($trusted) { OK "Certificado Gas+ confiado (Editores de confianza) - exe firmado corre sin aviso" }
  else { WARNX "Certificado Gas+ NO instalado aun (se instala al Aplicar)" }

  Head "ZeroTier"
  $zt = Get-Command zerotier-cli -ErrorAction SilentlyContinue
  if (-not $zt) { $ztexe = Join-Path ${env:ProgramFiles(x86)} "ZeroTier\One\zerotier-one_x64.exe"; if (Test-Path $ztexe) { $zt = $true } }
  if ($zt) {
    OK "ZeroTier instalado"
    try { & "${env:ProgramFiles(x86)}\ZeroTier\One\zerotier-cli.bat" listnetworks 2>$null | ForEach-Object { INFO $_ } } catch {}
  } else { BAD "ZeroTier NO instalado" }
  W ""
}

# ============================================================================ #
#  APLICAR
# ============================================================================ #
function Set-Regedit {
  Head "Registro"
  New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Force -ErrorAction SilentlyContinue | Out-Null
  Set-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name LocalAccountTokenFilterPolicy -Value 1 -Type DWord
  OK "LocalAccountTokenFilterPolicy = 1"
}

function Set-ProfilesPrivate {
  # REPARA: Windows bloquea WinRM (y limita otras cosas) si algun perfil de red
  # esta en 'Publico'. Lo pasamos a 'Privado'. Es lo que el usuario hacia a mano.
  try {
    $pubs = Get-NetConnectionProfile -ErrorAction SilentlyContinue | Where-Object { $_.NetworkCategory -eq 'Public' }
    foreach($p in $pubs){
      try { Set-NetConnectionProfile -InterfaceIndex $p.InterfaceIndex -NetworkCategory Private -ErrorAction Stop
            OK ("Perfil de red '" + $p.Name + "' -> Privado") }
      catch { WARNX ("No se pudo cambiar perfil '" + $p.Name + "' a Privado") }
    }
  } catch {}
}

function Enable-WinRMx {
  Head "WinRM"
  # 0) Reparar perfiles Publico->Privado (best effort; no aborta nada).
  Set-ProfilesPrivate
  # 1) Servicio arriba.
  try { Set-Service WinRM -StartupType Automatic -ErrorAction SilentlyContinue; Start-Service WinRM -ErrorAction SilentlyContinue } catch {}
  # 2) Registrar el endpoint de PowerShell Remoting. -SkipNetworkProfileCheck
  #    evita el error de "red Publica"; en su PROPIO try para que si igual
  #    tira excepcion NO se salte lo demas (esto era el bug: abortaba aqui).
  try { Enable-PSRemoting -Force -SkipNetworkProfileCheck -ErrorAction Stop | Out-Null; OK "PSRemoting registrado" }
  catch { WARNX "Enable-PSRemoting dio aviso; sigo con listener manual" }
  # 3) Crear el listener HTTP a mano. 'winrm create' NO revisa el perfil de red
  #    (a diferencia de quickconfig), asi que funciona aunque quede algo Publico.
  try {
    $lst = & cmd /c "winrm enumerate winrm/config/listener" 2>$null | Out-String
    if ($lst -notmatch "Transport\s*=\s*HTTP") {
      & cmd /c "winrm create winrm/config/Listener?Address=*+Transport=HTTP" 2>$null | Out-Null
    }
  } catch {}
  # 4) Auth.
  try { Set-Item WSMan:\localhost\Service\Auth\Basic -Value $true -ErrorAction SilentlyContinue } catch {}
  try { Set-Item WSMan:\localhost\Service\AllowUnencrypted -Value $false -ErrorAction SilentlyContinue } catch {}
  # 5) Firewall: grupo neutral (cualquier idioma) + regla propia por puerto.
  Enable-FwGroupNeutral "@FirewallAPI.dll,-30267" | Out-Null
  New-FwPort "Gas+ WinRM HTTP" @(5985) | Out-Null
  # 6) Verificar de verdad: servicio corriendo + puerto 5985 abierto.
  $st = (Get-Service WinRM -ErrorAction SilentlyContinue).Status
  if ($st -eq "Running" -and (FwPortOpen 5985)) { OK "WinRM 5985 abierto y corriendo" }
  elseif ($st -eq "Running") { WARNX "WinRM corriendo pero no confirme el puerto 5985" }
  else { BAD "WinRM: el servicio no quedo corriendo ($st)" }
}

function Enable-RDPx {
  Head "RDP"
  Set-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server" -Name fDenyTSConnections -Value 0 -Type DWord
  Set-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Name UserAuthentication -Value 1 -Type DWord -ErrorAction SilentlyContinue
  Enable-FwGroupNeutral "@FirewallAPI.dll,-28752" | Out-Null   # grupo "Escritorio remoto" (neutral)
  New-FwPort "Gas+ RDP" @(3389) | Out-Null
  if (FwPortOpen 3389) { OK "RDP habilitado con NLA, puerto 3389 abierto" } else { WARNX "RDP en registro OK; no confirme el puerto 3389" }
}

function Enable-SSHx {
  Head "OpenSSH Server"
  try {
    $cap = Get-WindowsCapability -Online -Name OpenSSH.Server* -ErrorAction SilentlyContinue
    if ($cap -and $cap.State -ne "Installed") { Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0 | Out-Null }
    Set-Service sshd -StartupType Automatic; Start-Service sshd
    New-FwPort "OpenSSH Server (Gas+)" @(22) | Out-Null
    # shell por defecto powershell (comodo para deploys)
    New-Item -Path "HKLM:\SOFTWARE\OpenSSH" -Force -ErrorAction SilentlyContinue | Out-Null
    Set-ItemProperty "HKLM:\SOFTWARE\OpenSSH" -Name DefaultShell -Value "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -ErrorAction SilentlyContinue
    OK "OpenSSH Server instalado, auto-inicio, corriendo (22)"
    if ($SshPubKey) {
      $akf = Join-Path $env:ProgramData "ssh\administrators_authorized_keys"
      if (-not (Test-Path $akf) -or -not ((Get-Content $akf -ErrorAction SilentlyContinue) -contains $SshPubKey)) {
        Add-Content -Path $akf -Value $SshPubKey
      }
      # ACL correcta para administrators_authorized_keys
      icacls $akf /inheritance:r /grant "Administrators:F" /grant "SYSTEM:F" 2>$null | Out-Null
      OK "Llave SSH autorizada (administrators_authorized_keys)"
    } else { WARNX "Sin -SshPubKey: SSH quedo por password. Pasa tu llave para acceso key-based." }
  } catch { BAD ("OpenSSH: " + $_.Exception.Message) }
}

function Enable-SMBx {
  Head "SMB / Compartir archivos"
  Enable-FwGroupNeutral "@FirewallAPI.dll,-28502" | Out-Null   # "Compartir archivos e impresoras" (neutral)
  Enable-FwGroupNeutral "@FirewallAPI.dll,-32752" | Out-Null   # "Deteccion de redes" (neutral)
  New-FwPort "Gas+ SMB" @(445,139) | Out-Null
  # permitir ping (comodo para diagnostico remoto), por regla propia
  try {
    Get-NetFirewallRule -DisplayName "Gas+ Ping ICMPv4" -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
    New-NetFirewallRule -DisplayName "Gas+ Ping ICMPv4" -Direction Inbound -Action Allow -Protocol ICMPv4 -IcmpType 8 -Profile Any | Out-Null
  } catch {}
  if (FwPortOpen 445) { OK "SMB (445/139) + descubrimiento + ping habilitados" } else { WARNX "SMB configurado; no confirme el puerto 445" }
}

function Enable-HyperVx {
  Head "Hyper-V"
  if ($SkipHyperV) { WARNX "Omitido (-SkipHyperV)"; return }
  try {
    $hv = Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All -ErrorAction SilentlyContinue
    if ($hv.State -eq "Enabled") { OK "Hyper-V ya habilitado"; return }
    $res = Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All -All -NoRestart -ErrorAction Stop
    OK "Hyper-V habilitado"
    if ($res.RestartNeeded) { $script:Reboot = $true; WARNX "Requiere REINICIO para activar Hyper-V" }
  } catch { BAD ("Hyper-V: " + $_.Exception.Message + " (verifica edicion Pro/Server + VT-x en BIOS)") }
}

function Install-ZeroTierx {
  Head "ZeroTier"
  if ($SkipZeroTier) { WARNX "Omitido (-SkipZeroTier)"; return }
  $ztcli = "${env:ProgramFiles(x86)}\ZeroTier\One\zerotier-cli.bat"
  if (-not (Test-Path $ztcli)) {
    try {
      $msi = Join-Path $env:TEMP "ZeroTierOne.msi"
      INFO "Descargando ZeroTier..."
      [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
      Invoke-WebRequest -Uri "https://download.zerotier.com/dist/ZeroTier%20One.msi" -OutFile $msi -UseBasicParsing
      Start-Process msiexec.exe -ArgumentList "/i `"$msi`" /qn /norestart" -Wait
      OK "ZeroTier instalado"
    } catch { BAD ("ZeroTier descarga/instalacion: " + $_.Exception.Message); return }
  } else { OK "ZeroTier ya instalado" }
  Start-Sleep -Seconds 3
  if ($ZtNetwork) {
    try { & $ztcli join $ZtNetwork | Out-Null; OK ("Unido a red ZeroTier {0}" -f $ZtNetwork) } catch { BAD "No se pudo unir a la red ZeroTier" }
  } else { WARNX "Sin -ZtNetwork: instalado pero sin unir a ninguna red." }
  try { $id = (& $ztcli info) -join " "; INFO ("Nodo ZeroTier: {0}" -f $id); WARNX "AUTORIZA este nodo en el panel de ZeroTier para que reciba IP." } catch {}
}

function Trust-GasPlusCert {
  Head "Certificado de firma Gas+ (confianza local)"
  $cer = Join-Path $here "gasplus-codesign.cer"
  if (-not (Test-Path $cer)) { WARNX "No encontre gasplus-codesign.cer junto al script; omito confianza"; return }
  try {
    Import-Certificate -FilePath $cer -CertStoreLocation Cert:\LocalMachine\Root -ErrorAction Stop | Out-Null
    Import-Certificate -FilePath $cer -CertStoreLocation Cert:\LocalMachine\TrustedPublisher -ErrorAction Stop | Out-Null
    OK "Certificado Gas+ instalado (Entidades de certificacion raiz + Editores de confianza)"
    INFO "Las proximas ejecuciones del .exe firmado NO mostraran aviso de editor desconocido."
  } catch {
    # Fallback por certutil si Import-Certificate no esta disponible.
    try {
      & certutil -addstore -f Root "$cer" 2>$null | Out-Null
      & certutil -addstore -f TrustedPublisher "$cer" 2>$null | Out-Null
      OK "Certificado Gas+ instalado (via certutil)"
    } catch { BAD ("No se pudo instalar el certificado de confianza: " + $_.Exception.Message) }
  }
}

function Aplicar-Todo {
  W ""
  W "*** MODO APLICAR - se haran cambios de configuracion ***" "Yellow"
  Trust-GasPlusCert
  Set-Regedit
  Enable-WinRMx
  Enable-RDPx
  Enable-SSHx
  Enable-SMBx
  Enable-HyperVx
  Install-ZeroTierx

  Head "RESULTADO"
  Get-Estado
  W "==================================================================" "Cyan"
  $ips = (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike "169.*" -and $_.IPAddress -ne "127.0.0.1" }).IPAddress -join ", "
  OK ("Maquina lista. IPs: {0}" -f $ips)
  INFO "Para conectarte:  ssh <usuario>@<IP>   |   RDP a <IP>   |   WinRM 5985"
  if ($script:Reboot -and -not $NoReboot) {
    W ""
    WARNX "Hyper-V requiere reinicio. Reiniciando en 30s... (Ctrl+C para cancelar)"
    Start-Sleep -Seconds 30
    Restart-Computer -Force
  } elseif ($script:Reboot) {
    WARNX "REINICIO PENDIENTE para activar Hyper-V (correr 'Restart-Computer' cuando puedas)."
  }
}

# ============================================================================ #
if ($Aplicar) { Aplicar-Todo } else {
  Get-Estado
  W "==================================================================" "Cyan"
  W "Esto fue SOLO LECTURA. Para aplicar los fixes, corre:" "White"
  W "  .\Provision-GasPlus.ps1 -Aplicar -ZtNetwork <red> -SshPubKey `"<tu-llave>`" -AllowCidr 10.14.0.0/16" "White"
}
