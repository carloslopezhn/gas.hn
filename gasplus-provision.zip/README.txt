================================================================================
 Provision-GasPlus  -  Herramienta de habilitacion remota (Grupo UTP / Gas+)
================================================================================

QUE HACE
  Deja una maquina Windows lista para administrarla remotamente e instalar Gas+
  (Hyper-V + VM Ubuntu). Habilita: Hyper-V, WinRM, RDP (NLA), OpenSSH Server con
  tu llave, SMB, reglas de firewall y las claves de registro necesarias; instala
  y une ZeroTier a tu red. Idempotente (se puede correr varias veces).

USO POR EL TECNICO INSTALADOR
  1) Doble clic en  1-Ver-Estado.bat     -> muestra el estado (no cambia nada).
  2) Doble clic en  2-Aplicar-Fixes.bat  -> aplica todo (pide UAC / admin).
     Al terminar reporta las IPs y, si hace falta, reinicia por Hyper-V.
  3) El tecnico te envia la IP / nodo ZeroTier. Vos autorizas el nodo en el
     panel de ZeroTier y ya controlas la maquina (ssh / rdp / winrm).

ANTES DE ENTREGAR (una sola vez)
  Edita  2-Aplicar-Fixes.bat  y reemplaza:
    ZTNET   = ID de tu red ZeroTier (16 hex)          ej: a581878f7debf3f2
    SSHKEY  = tu llave publica SSH (ssh-ed25519 AAAA...)
    CIDR    = rango permitido en el firewall          ej: 10.14.0.0/16
              (usa tu rango ZeroTier; asi no se abre nada a la LAN/Internet)

EMPAQUETAR COMO .EXE (opcional, para doble-clic sin ver el .bat)
  En una PC con PowerShell:
    Install-Module ps2exe -Scope CurrentUser -Force
    ps2exe .\Provision-GasPlus.ps1 .\Provision-GasPlus.exe -requireAdmin -title "Gas+ Provision" -company "Grupo UTP"
  Para que Windows/AV no lo marquen, FIRMA el .exe con un certificado de firma
  de codigo (Authenticode):
    Set-AuthenticodeSignature .\Provision-GasPlus.exe -Certificate $cert -TimestampServer "http://timestamp.digicert.com"

SEGURIDAD
  - SSH por LLAVE (no password). RDP con NLA.
  - Con -AllowCidr las reglas de firewall se limitan a ese rango (recomendado).
  - La herramienta no expone nada a Internet por si sola; el acceso remoto pasa
    por ZeroTier (o tu VPN/NAT).

REQUISITOS
  Windows 10/11 Pro o Windows Server (Hyper-V requiere edicion Pro/Server + VT-x
  activado en BIOS). Ejecutar como Administrador (la herramienta lo pide sola).
