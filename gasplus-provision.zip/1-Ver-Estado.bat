@echo off
title Gas+ Provision - ESTADO (solo lectura)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Provision-GasPlus.ps1"
echo.
pause
