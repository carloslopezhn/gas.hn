@echo off
title Gas+ Provision - APLICAR
REM ==== CONFIGURAR ANTES DE ENTREGAR AL TECNICO ====
set "ZTNET=REEMPLAZAR_RED_ZEROTIER"
set "SSHKEY=REEMPLAZAR_LLAVE_PUBLICA_SSH"
set "CIDR=10.14.0.0/16"
REM =================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Provision-GasPlus.ps1" -Aplicar -ZtNetwork %ZTNET% -SshPubKey "%SSHKEY%" -AllowCidr %CIDR%
echo.
pause
